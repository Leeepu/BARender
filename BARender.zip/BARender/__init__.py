import bpy
import subprocess
import sys
import os

# 获取 Blender Python 解释器的路径
blender_python_path = sys.executable

# 根据 Blender Python 解释器的路径构建 site-packages 路径
target_dir = os.path.join(os.path.dirname(os.path.dirname(blender_python_path)), "lib", "site-packages")

def install_dependencies():
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pywin32","--target", target_dir])
    except subprocess.CalledProcessError as e:
        print("依赖安装失败:")
        def draw(self, context):
            self.layout.label(text="插件所需的python库pywin32无法安装，请用管理员权限打开blender或请手动安装")
        bpy.context.window_manager.popup_menu(draw, title="依赖安装失败", icon='ERROR')

try:
    import win32file
except ImportError:
    install_dependencies()

import gpu
import numpy as np
import struct
from multiprocessing import shared_memory
import time
import threading
import enum
import traceback

bl_info = {
    "name": "BARender",
    "author": "Leepu",
    "blender":(4,0,0),
    "version": (1, 0, 0),
    "category": "Tool",
}   

def handler_store_viewport_buffer(self, context):
    if self.modal_redraw:
        store_viewport_buffer(self, context)
        self.modal_redraw = False

#操作blender的时候，暂停渲染，防止崩溃
class PauseRenderOperator(bpy.types.Operator):
    bl_idname = "barender.pause"
    bl_label = "Pause BARender"
    
    def  modal(self, context, event):
        global PAUSED
        if RUNNING:
            if not PAUSED:
                print("Resumed render")
            PAUSED = True
            return {'PASS_THROUGH'}
    
    def invoke(self, context, event):
        print("Invoking operator")
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

class ViewportBufferCopy(bpy.types.Operator):
    bl_idname = "view3d.viewport_buffer_copy"
    bl_label = "Store 3D View Framebuffer"    

    def __init__(self):
        self.modal_redraw = True
    
    def modal(self, context, event):
        global RUNNING
        if RUNNING:  
            self.modal_redraw = True
            return {'PASS_THROUGH'}
        else:
            self._handle_3d = bpy.types.SpaceView3D.draw_handler_remove(self._handle_3d, 'WINDOW')
            print("Removing draw handler")
            return {'CANCELLED'}

    #invoke方法会在operator被调用时执行
    def invoke(self, context, event):
        print("Invoking operator")
        #当viewport 被刷新时，会调用handler_store_viewport_buffer；如果只draw_handler_add，不通过modal_redraw控制，会一直调用handler_store_viewport_buffer
        #如果直接gpu.state.active_framebuffer_get()，会得到全屏的framebuffer，而不是viewport的framebuffer
        self._handle_3d = bpy.types.SpaceView3D.draw_handler_add(handler_store_viewport_buffer, (self, context), 'WINDOW', 'PRE_VIEW')
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

def start_copy_buffer():
    #启动operator，会调用invoke方法
    bpy.ops.view3d.viewport_buffer_copy('INVOKE_DEFAULT')

class BARenderPanel(bpy.types.Panel):
    bl_idname = "VIEW3D_PT_barender"
    bl_label = "BARender"
    bl_category = "Tool"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'

    def draw(self, context):
        #添加一个按钮
        layout = self.layout
        layout.operator("barender.start", text="Start")
        layout.operator("barender.finish", text="Finish")
     
class BARenderStartOperator(bpy.types.Operator):
    bl_idname = "barender.start"
    bl_label = "Start BARender"
    
    def execute(self, context):
        global RUNNING
        pipe_thread = threading.Thread(target=client)
        pipe_thread.start()
        RUNNING = True
        bpy.ops.barender.pause('INVOKE_DEFAULT')
        # start_copy_buffer() 
        return {'FINISHED'}
    
class BARenderFinishOperator(bpy.types.Operator):
    bl_idname = "barender.finish"
    bl_label = "Finish BARender"
    
    def execute(self, context):
        global RUNNING
        global shm
        #关闭线程，停止copy buffer
        RUNNING = False
        #关闭管道和共享内存
        # if pipe is not None:
        #     win32file.CloseHandle(pipe)
        # if shm is not None:
        #     shm.close()
        #     shm.unlink()
        #     shm = None
        return {'FINISHED'}

def register():
    bpy.utils.register_class(BARenderPanel)
    bpy.utils.register_class(BARenderStartOperator)
    bpy.utils.register_class(BARenderFinishOperator)
    bpy.utils.register_class(PauseRenderOperator)
    # bpy.utils.register_class(ViewportBufferCopy)

def unregister():
    bpy.utils.unregister_class(BARenderPanel)
    bpy.utils.unregister_class(BARenderStartOperator)
    bpy.utils.unregister_class(BARenderFinishOperator)
    bpy.utils.unregister_class(PauseRenderOperator)
    # bpy.utils.unregister_class(ViewportBufferCopy)

#定义全局变量
FLOAT_SIZE = struct.calcsize('f')  # 4 bytes per float
class RenderMethod(enum.Enum):
    Realtime = 'realtime'
    Offline = 'offline'
method = RenderMethod.Offline
PIPE_NAME = r'\\.\pipe\BlenderAePipe'
pipe = None
SHARED_MEMORY_NAME = 'blender_render_buffer'
shm:shared_memory.SharedMemory = None
framebuffer_image:bpy.types.Image = None
image_name = "viewport_image"
RUNNING = True
PAUSED = False

def serialize_dict(data_dict):
    return '\n'.join(f'{key}={value}' for key, value in data_dict.items())

def deserialize_dict(data_str):
    """
    将字符串反序列化为字典
    """
    data = {}
    for line in data_str.splitlines():
        if '=' in line:
            key, value = line.split('=', 1)
            data[key] = value
    return data

def init_framebuffer():
    global framebuffer_image
    global image_name
    if not image_name in bpy.data.images:
        framebuffer_image = bpy.data.images.new(image_name, 32, 32, float_buffer=True)
    else:
        framebuffer_image = bpy.data.images[image_name]
    # framebuffer_image = bpy.data.images.new(image_name, 32, 32, float_buffer=True)

def offline_render():
    global shm
    print("Rendering offline...")
    try:
        time_start = time.time()
        bpy.ops.render.render(animation=False, use_viewport=False, write_still=False)
        time_end = time.time()
        print("Render time:", time_end - time_start)
        time_start = time.time()
        # 获取渲染结果图像
        #TODO: 需要连接一个viewer node,否则只有默认的256*256分辨率
        #TODO:Viewer Node中的图像未经过后处理效果，AGX对应合成节点的从线性Rec709转换为基于sRGB的AgX
        #bpy.data.images['Render Result']可以save_render，但是无法直接获取像素值
        #save 和 save_render的区别：save_render的图片会经过后处理效果，save的图片不会
        render_buffer = bpy.data.images['Viewer Node']
        print("Render buffer size:", render_buffer.size[0], render_buffer.size[1])
        pixelBuffer = np.array(render_buffer.pixels[:], dtype=np.float32)
        buffer_size = pixelBuffer.nbytes  # 使用 nbytes 获取字节大小
        init_shared_memory(buffer_size)
        shm.buf[:buffer_size] = pixelBuffer.tobytes()
        time_end = time.time()
        print("Save time:", time_end - time_start)

    except Exception as e:
        print("Error in offline render:", e)

    return None  # 返回 None 以停止计时器

def test_offline_render():
    global framebuffer_image
    print("Rendering offline...")
    try:
        # bpy.context.scene.render.engine = 'BLENDER_EEVEE_NEXT'
        time_start = time.time()
        bpy.ops.render.render(animation=False, write_still=False)
        # bpy.data.images['Render Result'].save(filepath="D:/test.png")#Save image to a specific path using a scenes render settings
        # img = bpy.data.images['Render Result']
        # print(img)
        # print("Render buffer size:", img.size[0], img.size[1])
        # print("Render buffer pixels:", img.pixels[:])
        # 获取渲染结果图像
        #TODO: 需要连接一个viewer node,否则只有默认的256*256分辨率
        #显示渲染时间
        time_end = time.time()
        print("Render time:", time_end - time_start)
        time_start = time.time()
        render_buffer = bpy.data.images['Viewer Node']
        print("Render buffer size:", render_buffer.size[0], render_buffer.size[1])
        width = render_buffer.size[0]
        height = render_buffer.size[1]
        framebuffer_image.scale(width, height)
        pixelBuffer = np.array(render_buffer.pixels[:], dtype=np.float32)
        framebuffer_image.pixels.foreach_set(pixelBuffer.flatten())
        #保存为外部图像
        framebuffer_image.save(filepath="D:/test.png")#Save image to a specific path using a scenes render settings，包括后处理效果
        time_end = time.time()
        print("Save time:", time_end - time_start)
        

    except Exception as e:
        print("Error in offline render:", e)

    return None  # 返回 None 以停止计时器

def init_shared_memory(buffer_size):
    global shm
    if shm is None:
        try:    
            shm = shared_memory.SharedMemory(name=SHARED_MEMORY_NAME, create=True, size=buffer_size)
            print("Created new shared memory")
        except FileExistsError:
            shm = shared_memory.SharedMemory(name=SHARED_MEMORY_NAME)
            print("Shared memory already exists")
        except Exception as e:
            print("Shared memory error:", e)   

def test_viewport_render():
    """
    实时渲染视口图像
    """
    global framebuffer_image
    global shm
    global pipe
    print("Rendering viewport...")
    try:
        print("save img size:", framebuffer_image.size[0], framebuffer_image.size[1])
        framebuffer_image.save(filepath="D:/test.png")
        bpy.data.images.remove(framebuffer_image)
        # framebuffer_image.save(filepath="D:/test.png")
        # buffer_size = len(pixelBuffer) * FLOAT_SIZE

        # init_shared_memory(buffer_size)
        # shm.buf[:buffer_size] = memoryview(pixelBuffer).cast('B')
        # print("Shared memory size:", buffer_size)
        # print("已写入共享内存")

    except Exception as e:
        print("Error in viewport_render:", e)
        print(traceback.format_exc())
    print("已保存图像")
    return None  # 返回 None 以停止计时器

def write_img_to_shared_memory(buffer_size, pixelBuffer):
    """
    realtime render时，将图像写入共享内存
    """
    global shm
    try:
        init_shared_memory(buffer_size)
        shm.buf[:buffer_size] = memoryview(pixelBuffer).cast('B')
        print("已写入共享内存")
    except Exception as e:
        print("Error in write_img_to_shared_memory:", e)

def store_viewport_buffer(self, context):
    global framebuffer_image
    global shm
    global pipe
    try:
        #把framebuffer_image储存后，这个image就会被清空
        """One key limitation is that image buffers are not shared between different Image data-blocks, and they are not duplicated when copying an image.
So until a modified image buffer is saved on disk, duplicating its Image data-block will not propagate the underlying buffer changes to the new Image."""
        init_framebuffer()
        gpu.state.viewport_set(0, 0, 1920, 1080)
        framebuffer = gpu.state.active_framebuffer_get()
        viewport_info = gpu.state.viewport_get()
        width, height = viewport_info[2], viewport_info[3]
        print("Viewport size:", width, height)
        #framebuffer不能直接转换为图像，如果需要保存为外部图像，需要通过blender的Image对象进行转换，但是这里不需要
        print("img size:", framebuffer_image.size[0], framebuffer_image.size[1])
        framebuffer_image.scale(width, height) 
        #TODO:保存为外部图像的时候alpha通道不正确
        pixelBuffer = framebuffer.read_color(0, 0, width, height, 4, 0, 'FLOAT')
        pixelBuffer.dimensions = width * height * 4
        framebuffer_image.pixels.foreach_set(pixelBuffer) #实际上，这一步不需要，如果需要将图片保存到磁盘，需要这一步
        print("img size:", framebuffer_image.size[0], framebuffer_image.size[1])
        buffer_size = len(pixelBuffer) * FLOAT_SIZE
        print("Buffer size:", buffer_size)
        #TODO:写入的buffer总是上一次的buffer，获取最新的buffer
        write_img_to_shared_memory(buffer_size, pixelBuffer)
    except Exception as e:
        print("Error in viewport_render:", e)
        print(traceback.format_exc())

def viewport_render():
    """
    已启用，实时渲染获取buffer困难，且本质是低采样的渲染
    实时渲染视口图像
    """
    global framebuffer_image
    global shm
    global pipe
    print("Rendering viewport...")
    try:
        #TODO: 不固定分辨率
        #set viewport 1920*1080
        gpu.state.viewport_set(0, 0, 1920, 1080)
        framebuffer = gpu.state.active_framebuffer_get()
        viewport_info = gpu.state.viewport_get()
        width, height = viewport_info[2], viewport_info[3]
        
        #framebuffer不能直接转换为图像，需要通过blender的Image对象进行转换
        framebuffer_image.scale(width, height) 
        pixelBuffer = framebuffer.read_color(0, 0, width, height, 4, 0, 'FLOAT')
        pixelBuffer.dimensions = width * height * 4
        framebuffer_image.pixels.foreach_set(pixelBuffer)     
        buffer_size = len(pixelBuffer) * FLOAT_SIZE

        init_shared_memory(buffer_size)
        shm.buf[:buffer_size] = memoryview(pixelBuffer).cast('B')
        print("Shared memory size:", buffer_size)
        print("已写入共享内存")

    except Exception as e:
        print("Error in viewport_render:", e)
    #发送回复    
    # send_reply()
    return None  # 返回 None 以停止计时器

def send_reply():
    """
    发送回复数据
    """
    global pipe
    status = 'OK' if not PAUSED else 'PAUSED'  
    reply = {
        'time': time.strftime('%Y-%m-%d %H:%M:%S'),
        'status': status,
    }
    # 序列化数据
    reply_str = serialize_dict(reply)
    print("Sending reply...")
    win32file.WriteFile(pipe, reply_str.encode('utf-8'))
    print(f"Sent reply: {reply}")

def init_pipe():
    global pipe
    try:
        print("Attempting to connect to pipe...")
        pipe = win32file.CreateFile(
            PIPE_NAME,
            win32file.GENERIC_READ | win32file.GENERIC_WRITE, # 可读写
            0,#其他进程不能访问
            None,
            win32file.OPEN_EXISTING,#打开已经存在的管道
            0,
            None
        )
        if pipe is None:
            print("Failed to connect to pipe.")
            return

        print("Connected to pipe.")
    except Exception as e:
        print("Pipe connection error:", e)
        exit()

def read_pipe(pipe) -> dict:
    """
    读取管道数据
    """
    data_dict = {}
    try:
        data = win32file.ReadFile(pipe, 4096)[1]
        if not data:
            return {}
        # 解析数据
        data_str = data.decode('utf-8')
        data_dict = deserialize_dict(data_str)
        print(f"Received data: {data_dict}")
    except Exception as e:
        print("Error reading pipe:", e)
        exit()

    return data_dict

def refresh_space_view3d(context=bpy.context):
    # for area in context.screen.areas:
    #     if area.type == 'VIEW_3D':
    #         area.tag_redraw()
    #         print("Refreshed spaceview3d")
    #         return 1
    bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
    print("Refreshed spaceview3d")
    if RUNNING:
        return 1
    return None

def setRender(frame_number, cam_pos_x, cam_pos_y, cam_pos_z):
    bpy.context.scene.frame_set(frame_number)
    #设置相机位置
    # location_original = bpy.context.scene.camera.location
    # print("Original camera location:", location_original)
    # location = ((cam_pos_x-960)/1000, (cam_pos_y-540)/1000, (cam_pos_z+2666.7)/1000)
    # print("New camera location:", location)
    # bpy.context.scene.camera.location = location

    return None


def init_viewnode():
    bpy.context.scene.use_nodes = True
    #在渲染层后加入一个viewer node
    viewer_node = bpy.context.scene.node_tree.nodes.new('CompositorNodeViewer')
    links = bpy.context.scene.node_tree.links
    render_layers = bpy.context.scene.node_tree.nodes['渲染层']
    links.new(render_layers.outputs['Image'], viewer_node.inputs['Image'])
    return None



def client():  
    global pipe 
    global RUNNING
    global PAUSED
    bpy.app.timers.register(init_viewnode)
    init_pipe()

    try:
        while RUNNING:
            data = read_pipe(pipe)
            if data == {}:
                continue
            if data.get('Status','') == 'OK':
                PAUSED = False

            frame_number = int(data.get('Frame number', 0))
            #设置位置,实验性功能，暂时不使用,且ae与blender的坐标系不同
            cam_pos_x = float(data.get('Camera position x', 0))
            cam_pos_y = float(data.get('Camera position y', 0))
            cam_pos_z = float(data.get('Camera position z', 0))

            if method == RenderMethod.Realtime:
                #已放弃，因为无法获取最新的buffer且本质是低采样的渲染，实时渲染获取buffer困难（py脚本权限低）
                # 不应该在子线程中修改blender数据，https://docs.blender.org/api/current/bpy.app.timers.html#bpy.app.timers.register
                # bpy.app.timers.register(viewport_render)    
                #不能将send_reply放在viewport_render中，未知原因会导致发送失败
                #TODO: 确保send_reply在viewport_render之后执行
                bpy.context.scene.frame_set(frame_number)
                #刷新spaceview3d
                refresh_space_view3d(bpy.context)
                time.sleep(0.1)
                send_reply()
           
            if method == RenderMethod.Offline:
                #TODO:ae与blender的坐标系不同，需要转换
                if not PAUSED:
                    setRender(frame_number, cam_pos_x, cam_pos_y, cam_pos_z)
                    offline_render()    
                send_reply()

    except Exception as e:
        print("Pipe client error:", e)

    finally:
        #关闭管道
        if pipe is not None:
            win32file.CloseHandle(pipe)
        print("Client closed the pipe.")
        #关闭共享内存
        # if shm is not None:
        #     shm.close()
        #     shm.unlink()

if __name__ == "__main__":
    # init_framebuffer()
    register()